from distutils.core import setup

setup(
    name='crawler',
    version='0.1.1',
    description='General Python crawler module',
    author='itmeng',
    py_modules=['crawler.currency', 'crawler.meng']
)
